`Brought to You by Extreme Onion Team...`
![COVER](https://raw.githubusercontent.com/degeneratehyperbola/NEPS/master/cover.png)

<div align="center">

[![ISSUES](https://img.shields.io/github/issues/degeneratehyperbola/NEPS?color=orange&label=Issues&style=plastic)](https://github.com/degeneratehyperbola/NEPS/issues)
<!--[![VERSION](https://img.shields.io/github/v/release/degeneratehyperbola/NEPS?color=orange&label=Version&style=plastic)](https://github.com/degeneratehyperbola/NEPS/releases/latest)-->
[![LICENSE](https://img.shields.io/badge/License-BSD%203--Clause%20Modified-orange?style=plastic)](https://github.com/degeneratehyperbola/NEPS/blob/master/LICENSE.md)
[![PATREON](https://img.shields.io/badge/%20-Patreon-orange?style=plastic&logo=patreon&logoColor=444)](https://www.patreon.com/hyperbola)
[![PAYPAL](https://img.shields.io/badge/%20-PayPal-orange?style=plastic&logo=paypal&logoColor=444)](https://www.paypal.me/ivanhudikov)
[![STAR](https://img.shields.io/badge/%20-Star%20this%20project!-orange?style=plastic)](https://upload.wikimedia.org/wikipedia/commons/thumb/f/f1/Heart_coraz%C3%B3n.svg/1200px-Heart_coraz%C3%B3n.svg.png)
[![TRAILER](https://img.shields.io/badge/%20-NEPS%20Trailer-orange?style=plastic)](https://www.youtube.com/watch?v=pvU8gO66mTs)

[<img width="245" src="https://discord.com/api/guilds/715296405513830442/widget.png?style=banner3" alt="discord">](https://discord.gg/pwB3XBppVr)

</div>

This is a CS:GO multihack, originally developed as a griefing cheat but evolved into a multihack, with semi-rage, exploit and griefing oriented features that are actively supported by the developer. It has been in development for 2 years so far, and since its base - Osiris - seen many bloat removal, cleaning up and expanding while drifting away from the original premise of cheating in video games, competitive especially. 

![SCREENSHOT](https://raw.githubusercontent.com/degeneratehyperbola/NEPS/master/menu_neps.png)

NEPS has seen numerous performance improvements, even from an already fantastically optimized base, having both low-level and very situation-specific retouches, and as a proud owner of a 2013 thinkpad, I think NEPS's performance is better than most other options, especially on the low end of the spectrum.

## NEPS features
- Aimbot: aim assistance
- Triggerbot: automatically shoot a player if in front of crosshair
- Backtrack: abuse lag compensation to interact with opponent's previous records
- Anti-Aim: a tool to make You harder to hit, sometimes exploiting server-client desynchronization bug
- Chams or Chameleons: color and shade any model in a world to Your liking (also can indicate backtrack and anti-aim)
- Glow: similarly to chams creates a glowing halo around models
- ESP or Extra Sensory Perception: reveal critical info about players
- Visuals: modify visual aspects of the game to Your liking
- Skin Changer: equip any in-game weapon/player skin
- Sound: modulate any sound individually, or add custom kill, death and hit sounds
- Griefing: toolset for trolling/griefing players
- Exploits: abuse miscellaneous bugs of the game
- Movement: movement enhancement
- Misc: miscellaneous features that didn't get categorized, try them out among others!
- Style: customize the look of NEPS main menu
- Config: save and load configurations for every feature
- Color Palette: hold Your accent colors for configuring visual features
- Config Drag&Drop: You can drag'n'drop some individual items as well! Like colors, aimbot weapon settings, anti-aim conditionals, and ESP.

<sup>psst... right click to bring up the context menu</sup>

# How to obtain a working NEPS build?
Currently, weekly builds are available to Patreon supporters only. Builds for patrons are posted both on EOT Discord server and on Patreon.

[![PATREON](https://img.shields.io/badge/%20-Patreon-orange?style=plastic&logo=patreon&logoColor=444)](https://www.patreon.com/hyperbola)

## NEPS dependencies
- Visual Studio 2022
- Windows SDK 10.0.X.X
- Platform Toolset v143

# Acknowledgments
- [Daniel Krupiński](https://github.com/danielkrupinski) for [Osiris](https://github.com/danielkrupinski/Osiris) - an amazing fundament for a CS:GO cheat
- [omar (ocornut)](https://github.com/ocornut) and [contributors](https://github.com/ocornut/imgui/graphs/contributors) for THE solution when it comes to in-game overlays - [ImGui](https://github.com/ocornut/imgui)

# NEPS downloads
![TOTAL](https://img.shields.io/github/downloads/degeneratehyperbola/NEPS/total?color=orange&label=Total&style=plastic)
![LATEST](https://img.shields.io/github/downloads/degeneratehyperbola/NEPS/latest/total?color=orange&label=Latest%20release&style=plastic)

![SEPARATOR](https://raw.githubusercontent.com/degeneratehyperbola/NEPS/master/separator.png)
