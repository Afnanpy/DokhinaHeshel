#pragma once

namespace StreamProofESP
{
    void render() noexcept;
}
