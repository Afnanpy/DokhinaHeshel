#pragma once

enum class UserMessageType
{
	Text = 7,
	VoteStart = 46,
	VotePass = 47,
	VoteFailed = 48,
};
