#pragma once

class SteamId
{
	// TODO
};
